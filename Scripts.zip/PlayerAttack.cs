using System;
using System.Collections;
using System.Collections.Generic;
using System.Security.Cryptography;
using UnityEngine;
using Unity.Netcode;

public class PlayerAttack : NetworkBehaviour
{
    [SerializeField] GameObject prefab;
    [SerializeField] float range = 10.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (!IsOwner) {  return; }
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            Instantiate(prefab, new Vector3(transform.position.x, transform.position.y + range, transform.position.z), Quaternion.identity);
            Console.WriteLine("Attack Up");
        }
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            Instantiate(prefab, new Vector3(transform.position.x, transform.position.y - range, transform.position.z), Quaternion.identity);
            Console.WriteLine("Attack Down");
        }
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            Instantiate(prefab, new Vector3(transform.position.x + range, transform.position.y, transform.position.z), Quaternion.identity);
            Console.WriteLine("Attack Right");
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Instantiate(prefab, new Vector3(transform.position.x - range, transform.position.y, transform.position.z), Quaternion.identity);
            Console.WriteLine("Attack Left");
        }
    }
}
