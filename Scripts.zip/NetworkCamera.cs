using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Unity.Netcode;

public class NetworkCamera : NetworkBehaviour
{
    [SerializeField] GameObject Screen;

    public void Start()
    {
        if (IsOwner)
        {
            Screen.SetActive(true);
        }

    }


}
