using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Unity.Netcode;

public class Chat : NetworkBehaviour
{
    [SerializeField] TMP_InputField nameField;
    [SerializeField] TMP_Text textBox;


    public void AddText(string text)
    {
        if (nameField.text == null || nameField.text == "") 
        {
            textBox.text += System.Environment.NewLine + "Nobody: " + text;
           
        }
        else 
        {
            textBox.text += textBox.text + System.Environment.NewLine + nameField.text + ": " + text;
            
        }
        
    }
}
