using UnityEngine;
using UnityEngine.SceneManagement;
using Unity.Netcode;
using System.Security.Cryptography;
using System;

public class StartNetwork : MonoBehaviour
{
    
    

    public void StartSever()
    {
        NetworkManager.Singleton.StartServer();
    }
    public void StartHost()
    {
        NetworkManager.Singleton.StartHost();
    }
    public void StartClient()
    {
        NetworkManager.Singleton.StartClient();
    }

    
    
}
