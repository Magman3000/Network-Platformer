using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Design.Serialization;
using System.Diagnostics;
using System.Security.Cryptography;
using UnityEngine;
using Unity.Netcode;


public class PlayerMovement : NetworkBehaviour
{
    [SerializeField] float speed = 1;
    [SerializeField] float jumpForce = 1;
    [SerializeField] int maxJumps = 3;
    [SerializeField] Rigidbody rigidbody;
    public bool inputActive = true;
    int jumps;
    
    // Start is called before the first frame update
    void Start()
    {
        jumps = maxJumps;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 velocity = rigidbody.velocity;

        if (Input.GetKey("d"))
        {
            velocity.x += speed;
        }
        if (Input.GetKey("a")) 
        {
            velocity.x -= speed;
        }

        if (Input.GetKeyDown("space") && jumps > 0)
        {
            velocity.y += jumpForce;
            jumps -= 1;
        }

        if (inputActive)
        {
            rigidbody.velocity = velocity;
        }
        
        

    }
    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Player") || other.gameObject.CompareTag("Platform"))
        {
            jumps = maxJumps;
        }
    }
    public void Teleport(Vector3 location)
    {
        transform.position = location;
        rigidbody.velocity *= 0;
    }
    public void ToggleInput(bool value)
    {
        inputActive = value;
    }
}
