using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Unity.Netcode;
using TMPro;
using System.Text;
using System.Threading;

public class Finish : NetworkBehaviour
{
    [SerializeField] TMP_Text scoreBoard;
    float[] times = new float[5] { 0, 0, 0, 0, 0 };

    public void OnTriggerEnter(Collider other)
    {
        float temp;
        if (other.gameObject.CompareTag("Player"))
        {
            temp = other.gameObject.GetComponent<Timer>().time;

            for (int i = 0; i < times.Length; i++)
            {
                if (times[i] == 0)
                {
                    times[i] = temp;
                    break;
                }
                if (times[i] > temp)
                {
                    SetNewTime(i);
                    times[i] = temp;
                }
            }
            scoreBoard.text = "1: " + TimeConvertion(times[0]) + System.Environment.NewLine + "2: "
             + TimeConvertion(times[1]) + System.Environment.NewLine + "3: " + TimeConvertion(times[2]) + System.Environment.NewLine + "4: " +
             TimeConvertion(times[3]) + System.Environment.NewLine + "5: " + TimeConvertion(times[4]);

            other.gameObject.GetComponent<PlayerMovement>().Teleport(new Vector3(0, 0, 0));
            other.gameObject.GetComponent<Health>().RespawnChange(new Vector3(0, 0, 0));
            other.gameObject.GetComponent<Health>().HP = other.gameObject.GetComponent<Health>().maxHP;
            other.gameObject.GetComponent<Timer>().time = 0;
        }
    }

    void SetNewTime(int index)
    {
        float temp;

        for (int i = index; i < times.Length - 1; i++)
        {
            temp = times[i + 1];
            times[i + 1] = times[i];
        }

    }

    string TimeConvertion(float time)
    {
        float seconds;
        float minutes;
        string result;

        seconds = time % 60;
        minutes = (time - seconds) / 60;

        result = minutes + ":" + seconds;

        return result;
    }

}
