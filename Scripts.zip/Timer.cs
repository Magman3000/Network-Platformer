using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using System;
using Unity.Netcode;

public class Timer : NetworkBehaviour
{
    [SerializeField] TMP_Text timerText;
    [SerializeField] float deathPenalty = 10;
    public float time = 0;
    float minutes;
    float seconds;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        time += Time.deltaTime;

        seconds = time % 60;
        minutes = (time - seconds)/60;

        timerText.text = minutes + ":" + (Math.Round(seconds, 3)).ToString("#.###");
    }
    
    public void Died()
    {
        time += deathPenalty;
    }
}
