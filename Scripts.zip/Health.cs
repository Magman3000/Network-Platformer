using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Design.Serialization;
using System.Threading;
using UnityEngine;
using TMPro;
using Unity.Netcode;

public class Health : NetworkBehaviour
{
    [SerializeField] public float maxHP;
    [SerializeField] float regenSec;
    [SerializeField] float respawnProcentage = 1;
    [SerializeField] TMP_Text healthText;
    [SerializeField] Vector3 respawnLocation;
    public float HP;
    public float regen;
    // Start is called before the first frame update
    void Start()
    {
        HP = maxHP;
    }

    // Update is called once per frame
    void Update()
    {
        if (!IsOwner) { return; }
        regen += Time.deltaTime;

        if (regen >= regenSec && HP < maxHP)
        {
            regen = 0;
            HP += 1;
        }
        else if (HP > maxHP)
        {
            HP = maxHP;
        }

        if(HP <= 0)
        {
            gameObject.GetComponent<PlayerMovement>().Teleport(respawnLocation);
            gameObject.GetComponent<Timer>().Died();
            HP = maxHP * respawnProcentage;
        }
        healthText.text = "HP: " + HP;
    }
    public void HealthChange(float change)
    {
        HP += change;
    }
    public void RespawnChange(Vector3 vector)
    {
        respawnLocation = vector;
    }
}
